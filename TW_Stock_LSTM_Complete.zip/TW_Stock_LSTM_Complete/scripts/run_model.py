"""Run one of the four systems. Each system writes only its own output folder."""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.common import TZ, current_completed_session, sha256  # noqa: E402
from scripts.unified_csv import NAMES, NOT_APPLICABLE, blank_row, write_table  # noqa: E402

EXPECTED_WEIGHTS = "53a1467fdba66e7f22a45e5f2fbc1cb78fc99825b15d516b3e7153d7bfc28144"
EXPECTED_SIGNAL = "37591d21300977b9486212fc86fe257bb050db47177fa2f41bd7a8904919f659"
SIGNAL_CREATED = "2026-11-05T23:23:09.114628+08:00"


def run_day(now=None):
    now = now or datetime.now(TZ)
    return now, pd.Timestamp(now.astimezone(TZ).date()), pd.Timestamp(current_completed_session(now)).normalize()


def ledger_mode() -> str:
    path = ROOT / "research" / "v211" / "config" / "ledger.yaml"
    mode = "imported_research"
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if stripped.startswith("ledger_mode:"):
                mode = stripped.split(":", 1)[1].strip()
    if mode not in {"imported_research", "new_independent"}:
        raise SystemExit(f"ledger_mode 只能是 imported_research 或 new_independent：{mode}")
    return mode


def prepare_independent_ledger() -> Path:
    """A new book shares the frozen weights and does not import the published signal."""
    dest = ROOT / "research" / "v211" / "independent_ledger"
    market_src = ROOT / "experiments" / "results" / "v2" / "v211" / "market"
    if not (dest / "market" / "manifest.json").exists():
        if dest.exists():
            shutil.rmtree(dest)
        (dest / "market").mkdir(parents=True, exist_ok=True)
        for name in (
            "prices.csv",
            "prices_seed.csv",
            "sentiment.csv",
            "sentiment_seed.csv",
            "news_cache.csv",
            "manifest.json",
            "state.json",
            "fetch_audit.jsonl",
        ):
            shutil.copy2(market_src / name, dest / "market" / name)
        (dest / "daily").mkdir(parents=True, exist_ok=True)
        note = {
            "origin": "new_independent",
            "imported_developer_signal": False,
            "shared_weight_sha256": EXPECTED_WEIGHTS,
            "created_for": "this package copy only",
        }
        (dest / "LEDGER_ORIGIN.json").write_text(json.dumps(note, ensure_ascii=False, indent=2), encoding="utf-8")
    archived = ROOT / "research" / "v211" / "signal_registry" / "developer_original" / "2026-11-05.csv"
    if sha256(archived) != EXPECTED_SIGNAL:
        raise SystemExit("開發者原始訊號封存已被改動，停止建立新帳本")
    return dest


def _write_status(model: str, day: pd.Timestamp, payload: dict) -> None:
    folder = ROOT / "outputs" / model / str(day.date())
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "status.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    log_dir = ROOT / "logs" / model
    log_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(TZ).strftime("%Y%m%dT%H%M%S%f")
    (log_dir / f"{stamp}.log").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def _price_snapshot(completed: pd.Timestamp) -> tuple[Path | None, str]:
    path = ROOT / "data" / "snapshots" / str(completed.date()) / "prices.csv"
    if not path.exists():
        return None, "price_snapshot_missing"
    max_date = pd.Timestamp(pd.to_datetime(pd.read_csv(path, usecols=["Date"]).Date).max()).normalize()
    if max_date != completed:
        return None, f"snapshot_through_{max_date.date()}_is_not_{completed.date()}"
    return path, "ready"


def _sentiment_snapshot(completed: pd.Timestamp) -> tuple[Path | None, str]:
    path = ROOT / "data" / "snapshots" / str(completed.date()) / "sentiment.csv"
    if not path.exists():
        return None, "sentiment_snapshot_missing"
    frame = pd.read_csv(path)
    frame["Date"] = pd.to_datetime(frame["Date"]).dt.normalize()
    day = frame[frame.Date == completed]
    names = {"2330.TW", "2317.TW", "2603.TW", "2002.TW", "2891.TW"}
    if set(day.ticker.astype(str)) != names or day.Daily_Sentiment.isna().any():
        return None, "sentiment_incomplete"
    return path, "ready"


def load_fixture(name: str) -> dict:
    if name != "reproducible":
        raise SystemExit("目前只有 reproducible 測試資料")
    path = ROOT / "data" / "examples" / "reproducible" / "manifest.json"
    spec = json.loads(path.read_text(encoding="utf-8"))
    for key in ("prices", "sentiment"):
        file_path = ROOT / spec[key]
        digest = sha256(file_path)
        if digest != spec[f"{key}_sha256"]:
            raise SystemExit(f"{key} 雜湊與可重現測試資料不符：{digest}")
    return spec


def run_notebook(kind: str, mode: str, fixture: str = "") -> int:
    now, today, completed = run_day()
    feature = None
    feature_reason = "not_used"
    if fixture:
        spec = load_fixture(fixture)
        completed = pd.Timestamp(spec["as_of"]).normalize()
        price = ROOT / spec["prices"]
        price_reason = "reproducible_fixture"
        if kind == "555":
            feature = ROOT / spec["sentiment"]
            feature_reason = "reproducible_fixture"
        output_name = f"reproducible-{completed.date()}"
    else:
        price, price_reason = _price_snapshot(completed)
        if kind == "555":
            feature, feature_reason = _sentiment_snapshot(completed)
        output_name = str(today.date())
    ready = price is not None and (kind == "444" or feature is not None)
    payload = {
        "model": kind,
        "mode": mode,
        "status": "waiting",
        "training_executed": False,
        "forecast_produced": False,
        "completed_session": str(completed.date()),
        "run_date": str(today.date()),
        "fixture": fixture or "live_snapshot",
        "price_reason": price_reason,
        "sentiment_reason": feature_reason,
        "execution_assumption": "lstm-evaluation-v1; not the 555 V2 next-close research book",
    }
    if not ready:
        payload["reason"] = price_reason if price is None else feature_reason
        _write_status(kind, today, payload)
        print(json.dumps(payload, ensure_ascii=False), flush=True)
        return 2
    if mode == "check":
        payload["status"] = "ready_not_trained"
        payload["reason"] = "fixture is ready; check mode does not retrain" if fixture else "data snapshot covers the completed session; check mode does not retrain"
        _write_status(kind, today, payload)
        print(json.dumps(payload, ensure_ascii=False), flush=True)
        return 0
    out = ROOT / "outputs" / kind / output_name
    out.mkdir(parents=True, exist_ok=True)
    os.environ["LSTM_AS_OF_DATE"] = str(completed.date())
    os.environ["LSTM_PRICE_CSV"] = str(price)
    os.environ["LSTM_OUTPUT_DIR"] = str(out)
    os.environ["LSTM_SAVE_MODELS"] = "0"
    if feature is not None:
        os.environ["LSTM_FEATURE_CSV"] = str(feature)
    from scripts.execute_nb import execute

    execute(kind)
    payload["status"] = "success"
    payload["training_executed"] = True
    payload["forecast_produced"] = True
    _export_notebook_csv(kind, out, completed, price, payload)
    (out / "status.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    _write_status(kind, today, payload)
    print(json.dumps(payload, ensure_ascii=False), flush=True)
    return 0


def _export_notebook_csv(kind: str, out: Path, completed, price: Path, payload: dict) -> None:
    matches = list(out.rglob("next_day_recommendation.csv"))
    if not matches:
        payload["forecast_produced"] = False
        payload["unified_csv"] = NOT_APPLICABLE
        return
    frame = pd.read_csv(matches[-1])
    rows = []
    for _, item in frame.iterrows():
        row = blank_row()
        row.update({
            "model_id": kind,
            "model_version": "notebook_daily_retrain",
            "signal_date": str(item.get("Signal_Date", completed.date())),
            "run_date": payload["run_date"],
            "generated_at": str(item.get("Created_At", NOT_APPLICABLE)),
            "data_asof": str(completed.date()),
            "stock_id": item["Ticker"],
            "stock_name": NAMES.get(str(item["Ticker"]), NOT_APPLICABLE),
            "predicted_return_pct": item["Predicted_Return_Pct"],
            "prediction_horizon_days": 1,
            "rank": NOT_APPLICABLE,
            "target_weight": item.get("Target_Weight", NOT_APPLICABLE),
            "cash_weight": item.get("Cash_Weight", NOT_APPLICABLE),
            "risk_status": item["Risk_Off"] if "Risk_Off" in frame.columns else NOT_APPLICABLE,
            "intended_execution_date": item.get("Target_Date", NOT_APPLICABLE),
            "execution_price": NOT_APPLICABLE,
            "execution_status": NOT_APPLICABLE,
            "model_hash": NOT_APPLICABLE,
            "data_hash": sha256(price),
        })
        rows.append(row)
    destination = out / "unified_signal.csv"
    write_table(destination, rows, {
        "model_id": kind,
        "execution_assumption": payload["execution_assumption"],
        "native_column_copied": "Predicted_Return_Pct",
        "values_were_rescaled": False,
        "research_sample": False,
    })
    payload["unified_csv"] = str(destination.relative_to(ROOT)).replace("\\", "/")


def v2_date_record(signal_date: str, run_date: str, execution_date: str) -> dict:
    """Keep the four dates in separate fields. Data cutoff stays on the signal date."""
    signal_date = str(pd.Timestamp(signal_date).date())
    run_date = str(pd.Timestamp(run_date).date())
    execution_date = str(pd.Timestamp(execution_date).date())
    if signal_date == execution_date:
        raise AssertionError("預定成交日不能等於訊號日")
    return {
        "signal_date": signal_date,
        "run_date": run_date,
        "data_asof": signal_date,
        "intended_execution_date": execution_date,
        "signal_date_meaning": "訊號日：已完成交易日，特徵與收盤只到這一天",
        "run_date_meaning": "執行日：程式寫出這份檔案的台北日曆日",
        "data_asof_meaning": "資料截止日：允許進入模型的最後資料日，等於訊號日",
        "intended_execution_date_meaning": "預定成交日：下一個交易日收盤，這份預測尚未成交",
    }


def run_555_v2(mode: str) -> int:
    """Predict with the frozen weights. This does not publish a V2.11 signal."""
    os.environ.pop("TW_LSTM_V211_DIR", None)
    now, today, completed = run_day()
    import experiments.v2.v211 as tracker
    from experiments.v2.v211_market import PRICES, SENTIMENT, market_files_ready, prediction_gate

    payload = {
        "model": "555_v2",
        "mode": mode,
        "status": "waiting",
        "research_candidate": True,
        "official_555_replacement": False,
        "signal_published": False,
        "completed_session": str(completed.date()),
        "run_date": str(today.date()),
    }
    if not market_files_ready():
        payload["reason"] = "v211_market_not_ready"
        _write_status("555_v2", today, payload)
        print(json.dumps(payload, ensure_ascii=False), flush=True)
        return 2
    ready, reason = prediction_gate(pd.read_csv(PRICES), pd.read_csv(SENTIMENT), completed)
    if not ready:
        payload["reason"] = reason
        _write_status("555_v2", today, payload)
        print(json.dumps(payload, ensure_ascii=False), flush=True)
        return 2
    weight_path = tracker.WEIGHT_DIR / "weights.npz"
    digest = sha256(weight_path)
    if digest != EXPECTED_WEIGHTS:
        payload["status"] = "failed"
        payload["reason"] = "weight hash mismatch"
        payload["weight_sha256"] = digest
        _write_status("555_v2", today, payload)
        print(json.dumps(payload, ensure_ascii=False), flush=True)
        return 1
    from experiments.v2.v211_market import load_market_context

    context = load_market_context()
    card = tracker.fit_and_save(context)
    if not (tracker.WEIGHT_DIR / "model_card.json").exists() or sha256(weight_path) != digest:
        payload["status"] = "failed"
        payload["reason"] = "weights changed during reuse"
        _write_status("555_v2", today, payload)
        return 1
    rows, execution, _five = tracker.predict_rows(card, context, completed)
    dates = v2_date_record(str(completed.date()), str(today.date()), execution)
    out = ROOT / "outputs" / "555_v2" / str(today.date())
    out.mkdir(parents=True, exist_ok=True)
    export = rows.copy()
    export.insert(0, "Signal_Date", dates["signal_date"])
    export.insert(1, "Run_Date", dates["run_date"])
    export.insert(2, "Data_AsOf", dates["data_asof"])
    export.insert(3, "Planned_Execution_Date", dates["intended_execution_date"])
    export.to_csv(out / "prediction.csv", index=False, encoding="utf-8-sig")
    (out / "dates.json").write_text(json.dumps(dates, ensure_ascii=False, indent=2), encoding="utf-8")
    unified = []
    for _, item in rows.iterrows():
        row = blank_row()
        row.update({
            "model_id": "555_v2",
            "model_version": tracker.MODEL_VERSION,
            "signal_date": dates["signal_date"],
            "run_date": dates["run_date"],
            "generated_at": now.astimezone(TZ).isoformat(),
            "data_asof": dates["data_asof"],
            "stock_id": item["Ticker"],
            "stock_name": NAMES[item["Ticker"]],
            "predicted_return_pct": item["Predicted_Return_Pct"],
            "prediction_horizon_days": 5,
            "rank": int(item["Rank"]),
            "target_weight": item["Target_Weight"],
            "cash_weight": item["Cash_Weight"],
            "risk_status": "Risk_Off" if bool(item["Risk_Off"]) else "Risk_On",
            "intended_execution_date": dates["intended_execution_date"],
            "execution_price": NOT_APPLICABLE,
            "execution_status": "not_filled",
            "model_hash": digest,
            "data_hash": sha256(PRICES),
        })
        unified.append(row)
    write_table(out / "unified_signal.csv", unified, {
        "model_id": "555_v2",
        "execution_assumption": "next_session_close; rebalance every 5 sessions; risk-off gross cap 0.50",
        "prediction_horizon_days_meaning": "model label is a five-session return; the book fills at the next close",
        "research_sample": False,
        "v211_signal_written": False,
        "dates": dates,
        "note": "This CSV is a prediction export. Only the V2.11 ledger file is a research signal.",
    })
    payload.update({
        "status": "success",
        "reason": "prediction_written_not_a_research_signal",
        "weight_sha256": digest,
        "weights_reused": True,
        "dates": dates,
        "planned_execution": execution,
        "unified_csv": str((out / "unified_signal.csv").relative_to(ROOT)).replace("\\", "/"),
    })
    _write_status("555_v2", today, payload)
    print(json.dumps(payload, ensure_ascii=False), flush=True)
    return 0


def run_v211(mode: str) -> int:
    now, today, completed = run_day()
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT) + os.pathsep + env.get("PYTHONPATH", "")
    mode_name = ledger_mode()
    if mode_name == "new_independent":
        dest = prepare_independent_ledger()
        env["TW_LSTM_V211_DIR"] = str(dest)
        env["TW_LSTM_WEIGHT_DIR"] = str(ROOT / "experiments" / "results" / "v2" / "v211" / "weights")
    else:
        env.pop("TW_LSTM_V211_DIR", None)
        env.pop("TW_LSTM_WEIGHT_DIR", None)
    if mode == "check":
        env["TW_LSTM_SKIP_MARKET_UPDATE"] = "1"
    else:
        env.pop("TW_LSTM_SKIP_MARKET_UPDATE", None)
    signal = ROOT / "experiments" / "results" / "v2" / "v211" / "daily" / "2026-11-05.csv"
    before = sha256(signal)
    if before != EXPECTED_SIGNAL:
        payload = {"model": "v211", "status": "failed", "reason": "imported signal hash mismatch", "sha256": before}
        _write_status("v211", today, payload)
        print(json.dumps(payload, ensure_ascii=False), flush=True)
        return 1
    completed_run = subprocess.run(
        [sys.executable, "-m", "experiments.v2.v211_daily"],
        cwd=str(ROOT),
        env=env,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
    )
    after = sha256(signal)
    text = (completed_run.stdout or "") + ("\n" + completed_run.stderr if completed_run.stderr else "")
    log_dir = ROOT / "logs" / "v211"
    log_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(TZ).strftime("%Y%m%dT%H%M%S%f")
    (log_dir / f"{stamp}.log").write_text(text + f"\nexit {completed_run.returncode}\n", encoding="utf-8")
    payload = {
        "model": "v211",
        "mode": mode,
        "ledger_mode": mode_name,
        "status": "success" if completed_run.returncode == 0 else ("waiting" if completed_run.returncode == 2 else "failed"),
        "exit_code": int(completed_run.returncode),
        "completed_session": str(completed.date()),
        "run_date": str(today.date()),
        "imported_signal_sha256_before": before,
        "imported_signal_sha256_after": after,
        "imported_signal_unchanged": before == after,
        "imported_signal_created_at": SIGNAL_CREATED,
        "signal_origin": "developer_original_2026-11-05",
        "official_555_replacement": False,
        "stdout_tail": text[-2000:],
    }
    _write_status("v211", today, payload)
    print(json.dumps({key: value for key, value in payload.items() if key != "stdout_tail"}, ensure_ascii=False), flush=True)
    if after != before:
        return 1
    return int(completed_run.returncode)


def run(model: str, mode: str, fixture: str = "") -> int:
    os.chdir(ROOT)
    if fixture and model not in {"444", "555"}:
        raise SystemExit("reproducible 測試資料只供 444 與 555 使用")
    if model in {"444", "555"}:
        return run_notebook(model, mode, fixture)
    if model == "555_v2":
        return run_555_v2(mode)
    if model == "v211":
        return run_v211(mode)
    raise SystemExit(f"unknown model {model}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True, choices=["444", "555", "555_v2", "v211"])
    parser.add_argument("--mode", choices=["check", "full"], default="full")
    parser.add_argument("--fixture", default="", choices=["", "reproducible"])
    args = parser.parse_args()
    return run(args.model, args.mode, args.fixture)


if __name__ == "__main__":
    raise SystemExit(main())
