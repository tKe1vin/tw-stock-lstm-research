"""Write today's shared snapshot inside this package.

The bundled official price and sentiment files stay read-only. A failed
download does not relabel an older close as the completed session.
"""
from __future__ import annotations

import json
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.common import TZ, current_completed_session, sha256  # noqa: E402


def snapshot_dir(completed) -> Path:
    return ROOT / "data" / "snapshots" / str(pd.Timestamp(completed).date())


def _max_date(path: Path):
    if not path.exists():
        return None
    frame = pd.read_csv(path, usecols=["Date"])
    if frame.empty:
        return None
    return pd.Timestamp(pd.to_datetime(frame["Date"]).max()).normalize()


def sentiment_ready(path: Path, completed) -> bool:
    if not path.exists():
        return False
    frame = pd.read_csv(path)
    frame["Date"] = pd.to_datetime(frame["Date"]).dt.normalize()
    day = frame[frame.Date == pd.Timestamp(completed).normalize()]
    names = {"2330.TW", "2317.TW", "2603.TW", "2002.TW", "2891.TW"}
    if set(day.ticker.astype(str)) != names:
        return False
    if day.Daily_Sentiment.isna().any():
        return False
    if "Source_Status" in day.columns:
        known = day.Source_Status.fillna("").isin(["", "observed_article", "verified_no_matching_article"])
        if not bool(known.all()):
            return False
    return True


def build_snapshot(now=None, allow_download=True) -> dict:
    now = now or datetime.now(TZ)
    completed = pd.Timestamp(current_completed_session(now)).normalize()
    folder = snapshot_dir(completed)
    folder.mkdir(parents=True, exist_ok=True)
    price_path = folder / "prices.csv"
    sentiment_path = folder / "sentiment.csv"
    report = {
        "completed_session": str(completed.date()),
        "clock": now.astimezone(TZ).isoformat(),
        "prices_ready": False,
        "sentiment_ready": False,
        "price_error": None,
        "sentiment_error": None,
        "used_previous_day_as_today": False,
    }
    if allow_download:
        try:
            from scripts.prices import refresh_prices

            refresh_prices(completed, price_path)
        except Exception as exc:
            report["price_error"] = f"{type(exc).__name__}: {exc}"
    if _max_date(price_path) == completed:
        report["prices_ready"] = True
        report["price_sha256"] = sha256(price_path)
        report["price_source"] = "yfinance unadjusted Close"
    else:
        report["prices_ready"] = False
        report["price_through"] = str(_max_date(price_path).date()) if _max_date(price_path) is not None else None
    official = ROOT / "data" / "sentiment_features_2026.csv"
    if sentiment_ready(official, completed):
        frame = pd.read_csv(official)
        frame.to_csv(sentiment_path, index=False, encoding="utf-8-sig")
        report["sentiment_ready"] = True
        report["sentiment_source"] = "bundled official sentiment copy"
        report["sentiment_sha256"] = sha256(sentiment_path)
    else:
        report["sentiment_ready"] = False
        official_through = _max_date(official)
        report["sentiment_through"] = str(official_through.date()) if official_through is not None else None
        report["sentiment_error"] = "official sentiment does not cover the completed session; unfinished fetch is not treated as no news"
        if sentiment_path.exists() and not sentiment_ready(sentiment_path, completed):
            sentiment_path.unlink()
    report["snapshot_dir"] = str(folder.relative_to(ROOT)).replace("\\", "/")
    (folder / "manifest.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def main() -> int:
    report = build_snapshot(allow_download=True)
    print(json.dumps(report, ensure_ascii=False), flush=True)
    if report["prices_ready"] and report["sentiment_ready"]:
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
