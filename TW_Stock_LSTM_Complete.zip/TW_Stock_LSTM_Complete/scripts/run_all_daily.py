"""Run the four systems in order. One failure does not delete the others' files."""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.common import TZ, current_completed_session  # noqa: E402

ORDER = ["444", "555", "555_v2", "v211"]
LOCK = ROOT / "logs" / "orchestrator" / "run.lock"


def _alive(pid: int) -> bool:
    if os.name != "nt":
        try:
            os.kill(pid, 0)
        except OSError:
            return False
        return True
    import ctypes

    handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, int(pid))
    if not handle:
        return False
    ctypes.windll.kernel32.CloseHandle(handle)
    return True


def _acquire():
    LOCK.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(LOCK, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        try:
            holder = int(LOCK.read_text(encoding="utf-8").strip())
        except (OSError, ValueError):
            holder = None
        if holder and _alive(holder):
            return None
        try:
            LOCK.unlink()
        except OSError:
            return None
        try:
            fd = os.open(LOCK, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            return None
    os.write(fd, str(os.getpid()).encode("ascii"))
    return fd


def _release(fd) -> None:
    if fd is None:
        return
    os.close(fd)
    try:
        LOCK.unlink()
    except OSError:
        pass


def _run_one(model: str, mode: str) -> dict:
    log_dir = ROOT / "logs" / "orchestrator"
    log_dir.mkdir(parents=True, exist_ok=True)
    started = datetime.now(TZ)
    proc = subprocess.run(
        [sys.executable, str(ROOT / "scripts" / "run_model.py"), "--model", model, "--mode", mode],
        cwd=str(ROOT),
        env={**os.environ, "PYTHONPATH": str(ROOT)},
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
    )
    text = (proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else "")
    log_path = log_dir / f"{started.strftime('%Y%m%dT%H%M%S%f')}_{model}.log"
    log_path.write_text(text, encoding="utf-8")
    if proc.returncode == 0:
        status = "success"
    elif proc.returncode == 2:
        status = "waiting"
    else:
        status = "failed"
    return {
        "model": model,
        "status": status,
        "exit_code": int(proc.returncode),
        "log": str(log_path.relative_to(ROOT)).replace("\\", "/"),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["check", "full"], default="full")
    parser.add_argument("--skip-download", action="store_true")
    args = parser.parse_args()
    if sys.version_info[:2] != (3, 12):
        print(json.dumps({"status": "failed", "reason": f"python {sys.version}"}, ensure_ascii=False))
        return 1
    fd = _acquire()
    if fd is None:
        print(json.dumps({"status": "waiting", "reason": "another run is active"}, ensure_ascii=False))
        return 2
    summary = {}
    try:
        now = datetime.now(TZ)
        completed = current_completed_session(now)
        summary = {
            "started": now.isoformat(),
            "run_date": str(now.astimezone(TZ).date()),
            "completed_session": str(pd_date(completed)),
            "mode": args.mode,
            "clock_note": "15:00 Asia/Taipei is the completed-session boundary used by the existing calendar helper.",
            "steps": {},
        }
        from scripts.update_market_data import build_snapshot

        market = build_snapshot(now, allow_download=not args.skip_download and args.mode == "full")
        summary["market"] = market
        for model in ORDER:
            summary["steps"][model] = _run_one(model, args.mode)
            summary["steps"][model]["outputs_retained"] = True
        codes = [item["exit_code"] for item in summary["steps"].values()]
        if any(code not in (0, 2) for code in codes):
            code = 1
        elif any(code == 2 for code in codes):
            code = 2
        else:
            code = 0
        summary["exit_code"] = code
        summary["finished"] = datetime.now(TZ).isoformat()
        day = summary["run_date"]
        dest = ROOT / "outputs" / "daily_summary" / day
        dest.mkdir(parents=True, exist_ok=True)
        (dest / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
        return code
    finally:
        _release(fd)


def pd_date(value) -> str:
    import pandas as pd

    return str(pd.Timestamp(value).date())


if __name__ == "__main__":
    raise SystemExit(main())
