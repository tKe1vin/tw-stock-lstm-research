@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo 請先執行 install.bat。
  exit /b 1
)
.venv\Scripts\python.exe scripts\run_all_daily.py --mode full
exit /b %ERRORLEVEL%
