解壓後的正式價格與情緒副本在 data/prices 與 data/sentiment_features_2026.csv。這個目錄不覆寫它們。
