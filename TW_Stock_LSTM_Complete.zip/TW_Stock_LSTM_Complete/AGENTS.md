# AGENTS.md

這個資料夾是交給組長的獨立套件。請先讀 `AI_HANDOFF.md`、`README.md` 與 `QUICK_START.md`。

## 可以做的事

- 在這個資料夾執行 `install.bat`，只建立這裡的 `.venv`。
- 手動執行 `run_444.bat`、`run_555.bat`、`run_555_v2.bat`、`run_v211.bat` 或 `run_all.bat`。不必建立 Windows 工作排程。
- 用 `run_reproducible_444.bat` 與 `run_reproducible_555.bat` 重跑截止 2026-11-04 的 50 epoch 訓練。
- 讀取 `outputs/` 裡各系統自己的結果。

## 不要做的事

- 不要改 `experiments/results/v2/v211/daily/2026-11-05.csv` 與 `research/v211/signal_registry/developer_original/`。
- 不要重新選擇或重訓 `rolling_selected`。凍結權重 SHA-256 必須維持 `53a1467fdba66e7f22a45e5f2fbc1cb78fc99825b15d516b3e7153d7bfc28144`。
- 不要把 555 V2 寫成正式 555 的替代品，也不要把四套 ROI 排在同一張表。
- 不要建立名為 `TwStockLstmV211Daily` 的工作排程。
- 不要把兩台電腦的 V2.11 帳本合併成同一份正式發布紀錄。
- 不要把密碼、Token、使用者家目錄路徑寫進這個套件。
- 不要啟用 `.github/workflows/daily-lstm.yml`。那是完整性檢查用的副本。

## 執行事實

- Python 3.12。CPU 版 TensorFlow。不需要 GPU 或 WSL2。
- 路徑由檔案位置決定。不要把開發機的絕對路徑寫進程式。
- 444 與 555 的 Notebook 在 `notebooks/`。執行器只設定環境變數。
- 555 V2 與 V2.11 共用 `experiments/results/v2/v211/weights/weights.npz`。研究訊號只由 V2.11 寫入所選帳本。
- 結束代碼：0 完成，2 可稍後重試，1 失敗。昨天的訊號不會讓今天變成 0。
