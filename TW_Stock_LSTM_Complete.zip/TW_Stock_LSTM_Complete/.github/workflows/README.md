daily-lstm.yml 是完整性檢查用的副本。這個交付包沒有啟用 GitHub Actions，也不會把結果寫回開發專案。
