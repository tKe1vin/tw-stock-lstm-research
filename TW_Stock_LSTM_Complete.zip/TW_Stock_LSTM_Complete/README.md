# 台股 LSTM 完整交付套件

這個資料夾可以獨立解壓使用。它包含四套分開的系統，不需要開發專案或開發者的電腦。

| 系統 | 角色 | 單獨執行 | 輸出 |
| --- | --- | --- | --- |
| 444 | 原始基準模型，每次依原始 Notebook 重新訓練 | `run_444.bat` | `outputs/444/` |
| 555 | 原始多變量 LSTM，保留原本風控 | `run_555.bat` | `outputs/555/` |
| 555 V2 | `rolling_selected` 研究候選，只做預測 | `run_555_v2.bat` | `outputs/555_v2/` |
| V2.11 | 未來訊號、模擬成交與五日標籤 | `run_v211.bat` | `outputs/v211/` 與研究帳本 |

`run_all.bat` 會依序更新資料、執行四套系統，並把摘要寫到 `outputs/daily_summary/`。其中一套失敗或資料未到齊時，不會刪除其他系統已經寫好的檔案。

555 V2 沒有被證明優於固定等權或大盤，也不會自動取代正式 555。

## 第一次使用

1. 安裝 Python 3.12，並確認 `py -3.12` 可用。
2. 閱讀 `QUICK_START.md`。
3. 執行 `install.bat`。它只在這個資料夾建立 `.venv`。
4. 執行 `check_environment.bat`。
5. 執行想要的批次檔。

情緒模型 `IDEA-CCNL/Erlangshen-Roberta-110M-Sentiment` 不在 ZIP 裡。第一次更新新聞情緒時，程式會依該模型自己的授權從 Hugging Face 下載。沒有下載完成前，缺少情緒就是「尚未到齊」，不會被當成當日沒有新聞。

股價使用 yfinance 未調整收盤價。新聞使用鉅亨網公開介面。交易日使用 `exchange_calendars` 的 XTAI，並排除已確認的颱風休市：2026-07-10、2026-10-23。這套程式沒有內建 API 金鑰。

## 手動執行

四套模型都可以手動執行，不必建立 Windows 工作排程。

```bat
run_444.bat
run_555.bat
run_555_v2.bat
run_v211.bat
run_all.bat
```

離線重現 444 與 555 的 50 epoch 訓練時，使用套件內已固定的 2026-11-04 價格與情緒，輸出到 `outputs/444/reproducible-2026-11-04/` 與 `outputs/555/reproducible-2026-11-04/`。這是歷史重跑，不是當日正式建議，也不會改寫 V2.11 訊號。

```bat
run_reproducible_444.bat
run_reproducible_555.bat
```

## V2.11 帳本

預設 `research/v211/config/ledger.yaml` 是 `imported_research`。

- 2026-11-05 的訊號是開發者在 2026-11-05 23:23:09 +08:00 發布的原始檔，SHA-256 為 `37591d21300977b9486212fc86fe257bb050db47177fa2f41bd7a8904919f659`。
- 封存副本在 `research/v211/signal_registry/developer_original/`。
- 重新執行不會改寫這個檔案，也不會把解壓時間當成發布時間。
- `imported_research` 會沿用這個解壓目錄裡的帳本，之後的新日期只寫在這個目錄。
- `new_independent` 改寫 `research/v211/independent_ledger/`。它共用凍結權重，但不會把 2026-11-05 放進新帳本，也不會把它當成這台電腦重新發布的訊號。新帳本在下一個「今天已經收盤」的交易日之前，會拒絕補造較早的訊號。

兩台電腦各自解壓後，各自持有一份目錄。ZIP 沒有同步機制。兩台電腦都不應把自己的後續訊號稱為同一份唯一正式研究帳本。若要共用，必須先指定一台為唯一寫入端，再用檔案同步；不能把兩個 ZIP 的帳本合併。

開發機上的工作名稱 `TwStockLstmV211Daily` 與此套件無關。本套件預設不建立排程，而且拒絕再建立那個名稱。

## 工作排程

預設不建立排程。確認後才執行：

```bat
.venv\Scripts\python.exe scripts\setup_scheduler.py --install
```

移除時使用同一個工作名稱與 `--remove`。程式拒絕建立名為 `TwStockLstmV211Daily` 的工作。

## 仍然需要網路或外部檔案的部分

- 當日新收盤價：yfinance。
- 當日新情緒：鉅亨網與 Erlangshen 模型。
- 444 與 555 的完整重新訓練：快照必須涵蓋當日；`check` 模式只檢查、不訓練。
- GPU 與 WSL2 不是安裝條件。
