# 套件結構

四套系統的入口都在資料夾根目錄的批次檔。Python 入口是 `scripts/run_model.py` 與 `scripts/run_all_daily.py`。

`notebooks/` 與 `models/model_444`、`models/model_555` 裡的 Notebook 是同一份原始檔。執行器設定 `LSTM_OUTPUT_DIR`、`LSTM_PRICE_CSV` 與 `LSTM_FEATURE_CSV`，不修改 Notebook 內容。

`experiments/` 與 `scripts/` 是執行時需要的原始模組。路徑由檔案位置決定，所以解壓到任何資料夾都能執行。`experiments/results/v2/v211/` 是匯入的研究帳本，不是新的發布來源。

`data/prices/historical_prices.csv` 與 `data/sentiment_features_2026.csv` 是唯讀的正式副本。每日更新寫到 `data/snapshots/`。

`.github/workflows/daily-lstm.yml` 只是供完整性檢查使用的副本，這個 ZIP 沒有啟用 GitHub Actions。

555 V2 與 V2.11 共用 `experiments/results/v2/v211/weights/weights.npz`。預測匯出與研究訊號分開存放。
