# 安裝

1. 安裝 Python 3.12 64-bit。不要改掉其他專案正在使用的 Python。
2. 在這個資料夾執行 `install.bat`。
3. 安裝程式會建立 `.venv`，安裝 `requirements.txt`，再從 PyTorch CPU 套件索引安裝 `torch`。
4. `scripts/verify_models.py` 會計算 `weights.npz` 的 SHA-256，並把五檔權重載入 LSTM。

不需要 WSL2，也不需要 GPU。TensorFlow 使用 `tensorflow-cpu`。

情緒模型不會被打進 ZIP。`transformers` 會在第一次評分新聞時下載 `IDEA-CCNL/Erlangshen-Roberta-110M-Sentiment`。請先閱讀該模型頁上的授權。下載快取在使用者的 Hugging Face 目錄，不在這個專案裡。

若 `py -3.12` 不存在，安裝程式會停止，不會去呼叫 Microsoft Store 的 `python` 別名。
