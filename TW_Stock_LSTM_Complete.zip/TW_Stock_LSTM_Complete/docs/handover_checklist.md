# 交給組長前的檢查清單

## 這次已在新暫存目錄核對

- [x] 根目錄有 `AGENTS.md`、`README.md`、`QUICK_START.md`。
- [x] 根目錄有 `AI_HANDOFF.md`、`ARCHITECTURE.md`、`DATA_DICTIONARY.md`、`MODEL_CARDS.md`、`RESEARCH_HISTORY.md`、`HANDOVER_STATUS.md`。
- [x] 444 與 555 已用 2026-11-04 可重現資料跑完原始 50 epoch 設定。早停後的最佳 epoch 與輸出目錄寫在 `HANDOVER_STATUS.md`。
- [x] 訓練沒有改寫正式價格、正式情緒與 2026-11-05 訊號。
- [x] 555 V2 的訊號日、執行日、資料截止日、預定成交日分欄保存。
- [x] README 說明 `imported_research` 與 `new_independent`。新帳本沒有複製 2026-11-05。
- [x] 444、555、555 V2 的輸出目錄分開。
- [x] 四套模型都有手動批次檔。驗收沒有建立工作排程。
- [x] 套件原始檔沒有密碼、Token 或使用者家目錄路徑。

## 傳給組長時再看一次

- [ ] 解壓後的 ZIP SHA-256 等於旁邊的 `TW_Stock_LSTM_Complete.zip.sha256`。
- [ ] ZIP 內沒有 `.venv` 與 `__pycache__`。
- [ ] 組長自己的電腦執行 `install.bat` 與 `check_environment.bat`。
- [ ] 組長知道新的股價、新聞與 Erlangshen 模型需要網路，而且 ZIP 本身不含情緒模型。
- [ ] 若兩台電腦都要追蹤，先指定唯一寫入端。不要把兩份帳本合併成同一份正式訊號。
- [ ] 只有組長確認後才執行 `scripts\setup_scheduler.py --install`。工作名稱使用 `TwStockLstmCompleteDaily`。
