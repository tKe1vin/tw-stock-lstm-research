# AI 交接

對象是使用 Codex 或其他程式代理的組長。代理應先遵守 `AGENTS.md`。

## 套件裡有什麼

四套系統分開存放，也能用 `run_all.bat` 依序執行。

| 識別 | 程式 | 輸出 |
| --- | --- | --- |
| 444 | `notebooks/444_baseline.ipynb` | `outputs/444/` |
| 555 | `notebooks/555_multivariate.ipynb` | `outputs/555/` |
| 555_v2 | `experiments/v2/v211.py` 的 `predict_rows` | `outputs/555_v2/` |
| v211 | `experiments/v2/v211_daily.py` | 所選帳本與 `outputs/v211/` |

執行入口是 `scripts/run_model.py` 與 `scripts/run_all_daily.py`。批次檔只負責進入這個資料夾的虛擬環境。

## 目前凍結狀態

- 555 V2 版本字串：`rolling_selected_fold16_window756_carried`。
- 權重檔：`experiments/results/v2/v211/weights/weights.npz`。
- 已匯入訊號：2026-11-05，發布時間 `2026-11-05T23:23:09.114628+08:00`。
- 該訊號的計畫成交日是 2026-11-06 收盤，五日標籤日是 2026-11-13。
- 成熟訊號日數在這份匯入帳本中是 0。程式不會自動升級正式 555。

## 帳本模式

`research/v211/config/ledger.yaml` 的 `ledger_mode`：

- `imported_research`：使用 `experiments/results/v2/v211/`。2026-11-05 檔案保持原位元。
- `new_independent`：寫入 `research/v211/independent_ledger/`，並繼續讀取同一份凍結權重。新帳本不含 2026-11-05。

兩種模式都只寫自己的目錄。沒有雲端同步。

## 代理常見錯誤

- 把 `outputs/555_v2/` 的預測再寫進 V2.11 訊號檔，造成同日兩筆研究樣本。
- 用今天的收盤重算已發布訊號的目標權重。
- 情緒還沒抓完時，沿用前一日分數並標成今天。
- 把 444、555 的 `lstm-evaluation-v1` 報酬和 V2 的下一交易日收盤帳本相減。
