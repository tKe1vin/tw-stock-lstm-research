# 架構

套件根目錄就是 Python 匯入根目錄。`scripts/common.py` 的 `ROOT` 是 `scripts/` 的上一層，所以解壓到任何路徑都能執行。

## 四個執行路徑

1. `run_444.bat` 呼叫 `scripts/run_model.py --model 444 --mode full`。
2. `run_555.bat` 呼叫同一支程式的 `--model 555`。
3. `run_555_v2.bat` 載入凍結權重並寫預測，不呼叫 `commit_signal`。
4. `run_v211.bat` 執行 `python -m experiments.v2.v211_daily`。它才會處理不可覆蓋的訊號、模擬成交與成熟標籤。

`run_all.bat` 先呼叫 `scripts/update_market_data.py` 的快照函式，再依 444、555、555 V2、V2.11 的順序各開一個子程序。子程序的非 0 結束代碼不會刪除其他目錄。

## 為什麼保留 experiments 與 notebooks

444 與 555 的原始 Notebook 由 `scripts/execute_nb.py` 讀取 `notebooks/444_baseline.ipynb` 與 `notebooks/555_multivariate.ipynb`。同一份檔案也複製在 `models/model_444/` 與 `models/model_555/`，方便查看。

555 V2 與 V2.11 的匯入名稱是 `experiments.v2`、`experiments.horizon_experiment`、`experiments.risk_experiment` 與 `scripts`。這些模組因此留在套件根目錄，而不是再複製進每個模型的 `src/`。

## 資料寫入邊界

- `data/prices/historical_prices.csv` 與 `data/sentiment_features_2026.csv` 是唯讀正式副本。
- 每日新股價寫到 `data/snapshots/交易日/prices.csv`。
- 可重現訓練讀上述正式副本，輸出寫到 `outputs/444/reproducible-2026-11-04/` 與 `outputs/555/reproducible-2026-11-04/`。
- V2.11 市場帳本在 `experiments/results/v2/v211/market/`。`imported_research` 的訊號在 `experiments/results/v2/v211/daily/`。
- `new_independent` 改寫 `research/v211/independent_ledger/`。權重仍讀取 `experiments/results/v2/v211/weights/`。

## 排程

`scripts/setup_scheduler.py` 不加參數時只印出說明。`--install` 才建立 `TwStockLstmCompleteDaily`，並拒絕 `TwStockLstmV211Daily`。手動批次檔不依賴這項工作。

## GitHub Actions

`.github/workflows/daily-lstm.yml` 隨套件保存，是為了讓既有完整性檢查看得到同一相對路徑。這個 ZIP 沒有註冊或啟用該工作流程。
