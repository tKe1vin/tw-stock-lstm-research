"""Append-only market snapshot for the V2.11 tracker.

The official price file, official sentiment file, and experimental sentiment
copy stay untouched. New sessions are fetched with the same public sources the
daily notebooks already use, then stored under the V2.11 result directory.
A missing sentiment day is left missing. It is never filled from the day before.
"""
from __future__ import annotations

import json
import shutil
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

from experiments.horizon_experiment import SENTIMENT_PATH, executable_labels
from experiments.risk_experiment import MARKET, RUN, TICKERS, build_frames, load_panel, load_sentiment
from experiments.v2.guard import ROOT, sha256
from experiments.v2.v211 import LIVE, V211, assert_v211
from scripts.common import TZ, current_completed_session, sessions

MARKET_DIR = V211 / "market"
PRICES = MARKET_DIR / "prices.csv"
SENTIMENT = MARKET_DIR / "sentiment.csv"
PRICE_SEED = MARKET_DIR / "prices_seed.csv"
SENTIMENT_SEED = MARKET_DIR / "sentiment_seed.csv"
CACHE = MARKET_DIR / "news_cache.csv"
MANIFEST = MARKET_DIR / "manifest.json"
STATE = MARKET_DIR / "state.json"
AUDIT = MARKET_DIR / "fetch_audit.jsonl"
STAGING = MARKET_DIR / "yahoo_staging.csv"
PRICE_SOURCE = "yfinance unadjusted Close"
SENTIMENT_SOURCE = "cnyes tw_stock + IDEA-CCNL/Erlangshen-Roberta-110M-Sentiment"
CALENDAR = "exchange_calendars XTAI, excluding scripts.common.SPECIAL_MARKET_CLOSURES"
ALLOWED_SENTIMENT = {"observed_article", "verified_no_matching_article"}
PRICE_ORIGIN = RUN / "historical_prices.csv"
OFFICIAL_PRICES = ROOT / "data" / "prices" / "historical_prices.csv"
OFFICIAL_SENTIMENT = ROOT / "data" / "sentiment_features_2026.csv"
NAMES = TICKERS + [MARKET]


def market_files_ready():
    return PRICES.exists() and SENTIMENT.exists() and MANIFEST.exists() and PRICE_SEED.exists() and SENTIMENT_SEED.exists()


def _write_json(path, payload):
    path = assert_v211(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    temporary.replace(path)


def _append_audit(record):
    path = assert_v211(AUDIT)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")


def _read_json(path):
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def same_prefix(base, current, through, value):
    """True when every saved row on or before `through` still has the same value."""
    left = base.copy()
    right = current.copy()
    left["Date"] = pd.to_datetime(left["Date"]).dt.normalize()
    right["Date"] = pd.to_datetime(right["Date"]).dt.normalize()
    through = pd.Timestamp(through).normalize()
    left = left[left.Date <= through].sort_values(["Date", "ticker"])
    right = right[right.Date <= through].sort_values(["Date", "ticker"])
    if len(left) != len(right):
        return False
    if not left.ticker.astype(str).reset_index(drop=True).equals(right.ticker.astype(str).reset_index(drop=True)):
        return False
    if not left.Date.reset_index(drop=True).equals(right.Date.reset_index(drop=True)):
        return False
    a = pd.to_numeric(left[value], errors="coerce").to_numpy(dtype=float)
    b = pd.to_numeric(right[value], errors="coerce").to_numpy(dtype=float)
    return bool(np.allclose(a, b, rtol=0, atol=1e-8, equal_nan=True))


def sentiment_day_ready(frame, day, tickers=None):
    tickers = list(tickers or TICKERS)
    if frame is None or len(frame) == 0 or "Source_Status" not in frame.columns:
        return False
    work = frame.copy()
    work["Date"] = pd.to_datetime(work["Date"]).dt.normalize()
    part = work[work.Date == pd.Timestamp(day).normalize()]
    if set(part.ticker.astype(str)) != set(tickers):
        return False
    values = pd.to_numeric(part.Daily_Sentiment, errors="coerce")
    if values.isna().any() or not bool(values.between(-1, 1).all()):
        return False
    return set(part.Source_Status.astype(str)).issubset(ALLOWED_SENTIMENT)


def prediction_gate(prices, sentiment, completed):
    """Publish only when the completed session has its own prices and sentiment."""
    completed = pd.Timestamp(completed).normalize()
    work = prices.copy()
    work["Date"] = pd.to_datetime(work["Date"]).dt.normalize()
    day = work[work.Date == completed]
    names = set(day.ticker.astype(str))
    closes = pd.to_numeric(day.Close, errors="coerce") if len(day) else pd.Series(dtype=float)
    if names != set(NAMES) or closes.isna().any() or (closes.to_numpy(dtype=float) <= 0).any():
        return False, "prices_missing"
    if not sentiment_day_ready(sentiment, completed):
        return False, "sentiment_waiting"
    return True, "ready"


def select_new_price_rows(ledger, incoming, as_of, required_sessions, names):
    """Rows strictly after the saved ledger. Existing dates are never returned."""
    saved = ledger.copy()
    fresh = incoming.copy()
    saved["Date"] = pd.to_datetime(saved["Date"]).dt.normalize()
    fresh["Date"] = pd.to_datetime(fresh["Date"]).dt.normalize()
    as_of = pd.Timestamp(as_of).normalize()
    required = pd.DatetimeIndex(required_sessions).normalize()
    required = required[(required > saved.Date.max()) & (required <= as_of)]
    if len(required) == 0:
        return fresh.iloc[0:0].copy(), []
    panel = fresh.pivot(index="Date", columns="ticker", values="Close")
    missing = []
    for day in required:
        if day not in panel.index or any(name not in panel.columns for name in names):
            missing.append(str(pd.Timestamp(day).date()))
            continue
        values = pd.to_numeric(panel.loc[day, list(names)], errors="coerce").to_numpy(dtype=float)
        if not np.isfinite(values).all() or (values <= 0).any():
            missing.append(str(pd.Timestamp(day).date()))
    if missing:
        return None, missing
    new = fresh[fresh.Date.isin(required) & fresh.ticker.astype(str).isin(names)].copy()
    saved_keys = set(zip(saved.Date, saved.ticker.astype(str)))
    overlap = [day for day, ticker in zip(new.Date, new.ticker.astype(str)) if (day, ticker) in saved_keys]
    if overlap:
        raise RuntimeError("新價格碰到已保存的歷史列")
    return new.sort_values(["Date", "ticker"]).reset_index(drop=True), []


def price_basis_ok(ledger, incoming):
    saved = ledger.copy()
    fresh = incoming.copy()
    saved["Date"] = pd.to_datetime(saved["Date"]).dt.normalize()
    fresh["Date"] = pd.to_datetime(fresh["Date"]).dt.normalize()
    left = saved.pivot(index="Date", columns="ticker", values="Close")
    right = fresh.pivot(index="Date", columns="ticker", values="Close")
    common = left.index.intersection(right.index)
    if len(common) == 0 or left.index.max() not in common:
        return False, {}
    day = left.index.max()
    diffs = {}
    for name in NAMES:
        base = float(left.loc[day, name])
        other = float(right.loc[day, name])
        diffs[name] = abs(base - other) / abs(base)
        if diffs[name] > 0.002:
            return False, diffs
    return True, diffs


def rows_for_sessions(cache, session_days):
    """Score each requested session from that session's articles only."""
    old = cache if cache is not None else pd.DataFrame()
    rows = []
    for day in session_days:
        stamp = str(pd.Timestamp(day).date())
        for ticker in TICKERS:
            if len(old) == 0:
                part = old
            else:
                part = old.loc[(old.Date.astype(str) == stamp) & (old.ticker.astype(str) == ticker)]
            latest = part["publish_time"].max() if len(part) else None
            rows.append({
                "Date": pd.Timestamp(day).normalize(),
                "ticker": ticker,
                "Daily_Sentiment": float(part.Daily_Sentiment.astype(float).mean()) if len(part) else 0.0,
                "News_Count": int(len(part)),
                "Latest_News_Timestamp": latest,
                "Source_Status": "observed_article" if len(part) else "verified_no_matching_article",
                "Scoring_Model": part.Model_ID.iloc[0] if len(part) else "neutral_no_news",
            })
    built = pd.DataFrame(rows)
    if not built.Daily_Sentiment.between(-1, 1).all():
        raise RuntimeError("情緒分數超出 -1 到 1")
    return built


def locked_signal_dates():
    found = set()
    if not LIVE.exists():
        return found
    for path in LIVE.glob("*.csv"):
        frame = pd.read_csv(path, usecols=["Signal_Date"])
        found.add(pd.Timestamp(frame.Signal_Date.iloc[0]).normalize())
    return found


def _copy_once(source, destination):
    destination = assert_v211(destination)
    if destination.exists():
        raise RuntimeError(f"快照已存在，拒絕重抄：{destination.name}")
    shutil.copyfile(source, destination)
    return sha256(destination)


def _clear_incomplete_seed():
    if MANIFEST.exists():
        return
    for path in (PRICE_SEED, SENTIMENT_SEED, PRICES, SENTIMENT):
        if path.exists():
            path.unlink()


def seed_market():
    if MANIFEST.exists():
        manifest = _read_json(MANIFEST)
        if sha256(PRICE_SEED) != manifest["price_seed_sha256"] or sha256(SENTIMENT_SEED) != manifest["sentiment_seed_sha256"]:
            raise RuntimeError("V2.11 種子快照被改過，停止更新")
        if not PRICES.exists() or not SENTIMENT.exists():
            raise RuntimeError("V2.11 市場帳本不完整，拒絕重抄種子")
        return manifest
    _clear_incomplete_seed()
    for path in (PRICE_ORIGIN, SENTIMENT_PATH):
        if not path.exists():
            raise FileNotFoundError(path)
    assert_v211(MARKET_DIR / "manifest.json")
    price_dates = pd.to_datetime(pd.read_csv(PRICE_ORIGIN, usecols=["Date"]).Date)
    sentiment_dates = pd.to_datetime(pd.read_csv(SENTIMENT_PATH, usecols=["Date"]).Date)
    price_hash = _copy_once(PRICE_ORIGIN, PRICE_SEED)
    sentiment_hash = _copy_once(SENTIMENT_PATH, SENTIMENT_SEED)
    _copy_once(PRICE_SEED, PRICES)
    _copy_once(SENTIMENT_SEED, SENTIMENT)
    manifest = {
        "price_origin": str(PRICE_ORIGIN.relative_to(ROOT)),
        "sentiment_origin": str(SENTIMENT_PATH.relative_to(ROOT)),
        "price_origin_sha256_at_seed": sha256(PRICE_ORIGIN),
        "sentiment_origin_sha256_at_seed": sha256(SENTIMENT_PATH),
        "official_price_sha256_at_seed": sha256(OFFICIAL_PRICES),
        "official_sentiment_sha256_at_seed": sha256(OFFICIAL_SENTIMENT),
        "price_seed_sha256": price_hash,
        "sentiment_seed_sha256": sentiment_hash,
        "price_seed_through": str(price_dates.max().date()),
        "sentiment_seed_through": str(sentiment_dates.max().date()),
        "seeded_at": datetime.now(TZ).isoformat(),
        "note": "Rows on or before the seed dates are never replaced.",
    }
    _write_json(MANIFEST, manifest)
    return manifest


def assert_history_intact(manifest):
    if sha256(PRICE_SEED) != manifest["price_seed_sha256"] or sha256(SENTIMENT_SEED) != manifest["sentiment_seed_sha256"]:
        raise RuntimeError("V2.11 種子快照被改過，停止更新")
    prices = pd.read_csv(PRICES)
    sentiment = pd.read_csv(SENTIMENT)
    if not same_prefix(pd.read_csv(PRICE_SEED), prices, manifest["price_seed_through"], "Close"):
        raise RuntimeError("已保存的歷史股價被改寫，停止發布")
    if not same_prefix(pd.read_csv(SENTIMENT_SEED), sentiment, manifest["sentiment_seed_through"], "Daily_Sentiment"):
        raise RuntimeError("已保存的歷史情緒被改寫，停止發布")


def _append_csv(path, new_rows):
    """Add rows without rewriting the bytes already saved."""
    current = pd.read_csv(path)
    header = list(current.columns)
    current["Date"] = pd.to_datetime(current["Date"]).dt.normalize()
    fresh = new_rows.copy()
    fresh["Date"] = pd.to_datetime(fresh["Date"]).dt.normalize()
    keys = set(zip(current.Date, current.ticker.astype(str)))
    clash = [str(day.date()) for day, ticker in zip(fresh.Date, fresh.ticker.astype(str)) if (day, ticker) in keys]
    if clash:
        raise RuntimeError(f"拒絕覆蓋既有列：{sorted(set(clash))}")
    fresh["Date"] = fresh["Date"].dt.strftime("%Y-%m-%d")
    body = fresh[header].to_csv(index=False, header=False, lineterminator="\r\n", na_rep="")
    original = path.read_bytes()
    if not original.endswith(b"\n"):
        original += b"\r\n"
    temporary = assert_v211(path.with_suffix(path.suffix + ".tmp"))
    temporary.write_bytes(original + body.encode("utf-8"))
    temporary.replace(path)


def _remember(day, report):
    state = _read_json(STATE)
    sessions_state = state.setdefault("sessions", {})
    key = str(pd.Timestamp(day).date())
    if key not in sessions_state and report.get("prices_ready") and report.get("sentiment_ready"):
        sessions_state[key] = {
            "ready_at": report.get("fetched_at"),
            "price_sha256": report.get("price_sha256"),
            "sentiment_sha256": report.get("sentiment_sha256"),
        }
        _write_json(STATE, state)
        return sessions_state[key]
    return sessions_state.get(key)


def source_for(day):
    info = _read_json(STATE).get("sessions", {}).get(str(pd.Timestamp(day).date()))
    if not info:
        return None
    return {
        "price_source": PRICE_SOURCE,
        "sentiment_source": SENTIMENT_SOURCE,
        "calendar": CALENDAR,
        "price_sha256": info.get("price_sha256"),
        "sentiment_sha256": info.get("sentiment_sha256"),
        "fetched_at": info.get("ready_at"),
        "used_previous_day_sentiment": False,
    }


def extend_prices(as_of, now, report):
    ledger = pd.read_csv(PRICES)
    ledger["Date"] = pd.to_datetime(ledger["Date"]).dt.normalize()
    as_of = pd.Timestamp(as_of).normalize()
    have = ledger.Date.max()
    report["prices_through"] = str(have.date())
    report["price_sha256"] = sha256(PRICES)
    if have >= as_of:
        got = set(ledger.loc[ledger.Date == as_of, "ticker"].astype(str))
        closes = pd.to_numeric(ledger.loc[ledger.Date == as_of, "Close"], errors="coerce")
        if got != set(NAMES) or closes.isna().any() or (closes.to_numpy(dtype=float) <= 0).any():
            raise RuntimeError(f"{as_of.date()} 的股價欄位不完整")
        report["prices_ready"] = True
        report["prices_through"] = str(as_of.date())
        report["appended_price_dates"] = []
        report["price_sha256"] = sha256(PRICES)
        return
    from scripts.prices import refresh_prices

    refresh_prices(as_of, assert_v211(STAGING))
    incoming = pd.read_csv(STAGING)
    ok, diffs = price_basis_ok(ledger, incoming)
    report["price_overlap_relative_diff"] = diffs
    if not ok:
        raise RuntimeError("Yahoo 與已保存收盤不一致，拒絕接上新日期")
    required = sessions(have + pd.Timedelta(days=1), as_of)
    new, missing = select_new_price_rows(ledger, incoming, as_of, required, NAMES)
    if missing:
        raise RuntimeError(f"價格缺少交易日：{missing}")
    report["appended_price_dates"] = []
    if len(new):
        _append_csv(PRICES, new[list(ledger.columns)])
        report["appended_price_dates"] = sorted({str(pd.Timestamp(day).date()) for day in new.Date})
    report["prices_ready"] = True
    report["prices_through"] = str(as_of.date())
    report["price_sha256"] = sha256(PRICES)
    report["price_fetched_at"] = now.astimezone(TZ).isoformat()


def extend_sentiment(as_of, now, report):
    from scripts.news_update import MODEL_ID, fetch_day, matches, to_signal_date, SentimentScorer

    manifest = _read_json(MANIFEST)
    existing = pd.read_csv(SENTIMENT)
    existing["Date"] = pd.to_datetime(existing["Date"]).dt.normalize()
    as_of = pd.Timestamp(as_of).normalize()
    seed_end = pd.Timestamp(manifest["sentiment_seed_through"]).normalize()
    locked = locked_signal_dates()
    needed = list(sessions(seed_end + pd.Timedelta(days=1), as_of))
    missing = []
    for day in needed:
        if day in locked:
            if not sentiment_day_ready(existing, day):
                raise RuntimeError(f"{pd.Timestamp(day).date()} 已有訊號，但情緒不完整")
            continue
        if not sentiment_day_ready(existing, day):
            missing.append(pd.Timestamp(day).normalize())
    report["sentiment_through"] = str(existing.Date.max().date())
    report["sentiment_sha256"] = sha256(SENTIMENT)
    report["appended_sentiment_dates"] = []
    if not missing:
        report["sentiment_ready"] = sentiment_day_ready(existing, as_of)
        if not report["sentiment_ready"]:
            raise RuntimeError(f"{as_of.date()} 的情緒未到齊")
        return
    start = missing[0] - pd.Timedelta(days=1)
    scanned = []
    for date in pd.date_range(start, as_of, freq="D"):
        entries = fetch_day(date)
        print(f"[V211][NEWS] {date.strftime('%Y-%m-%d')}: fetched {len(entries)} articles", flush=True)
        scanned.extend(entries)
    old = pd.read_csv(CACHE, dtype={"news_id": str}) if CACHE.exists() else pd.DataFrame()
    already = set(zip(old.news_id.astype(str), old.ticker.astype(str))) if len(old) else set()
    new = []
    for article in scanned:
        signal = to_signal_date(article["publish_time"])
        if signal <= seed_end:
            continue
        content = article["title"] + " " + article["summary"]
        for ticker in TICKERS:
            key = (article["news_id"], ticker)
            if key in already or not matches(content, ticker):
                continue
            new.append({
                "news_id": article["news_id"],
                "ticker": ticker,
                "publish_time": article["publish_time"],
                "Date": str(signal.date()),
                "text": content,
            })
            already.add(key)
    if new:
        scorer = SentimentScorer()
        scores = {}
        for row in new:
            if row["news_id"] not in scores:
                scores[row["news_id"]] = scorer.score(row["text"][:1600])
            row["Daily_Sentiment"] = scores[row["news_id"]]
            row["Model_ID"] = MODEL_ID
            del row["text"]
        new_frame = pd.DataFrame(new)
        old = pd.concat([old, new_frame], ignore_index=True)
    if len(old):
        old = old.drop_duplicates(["news_id", "ticker"]).sort_values(["Date", "ticker", "news_id"])
    built = rows_for_sessions(old, missing)
    for day in missing:
        if not sentiment_day_ready(built, day):
            raise RuntimeError(f"{pd.Timestamp(day).date()} 情緒仍不完整，不寫入")
    if existing.Date.isin(missing).any():
        raise RuntimeError("情緒檔含有未完成日期，拒絕改寫已保存的列")
    if len(old):
        temporary = assert_v211(CACHE.with_suffix(CACHE.suffix + ".tmp"))
        old.to_csv(temporary, index=False, encoding="utf-8-sig", lineterminator="\r\n")
        temporary.replace(assert_v211(CACHE))
    _append_csv(SENTIMENT, built)
    report["sentiment_ready"] = True
    report["sentiment_through"] = str(as_of.date())
    report["sentiment_sha256"] = sha256(SENTIMENT)
    report["appended_sentiment_dates"] = [str(pd.Timestamp(day).date()) for day in missing]
    report["sentiment_fetched_at"] = now.astimezone(TZ).isoformat()
    report["new_articles"] = len(new)


def load_market_context():
    if not market_files_ready():
        raise FileNotFoundError("V2.11 市場快照尚未建立")
    manifest = _read_json(MANIFEST)
    assert_history_intact(manifest)
    raw_max = pd.to_datetime(pd.read_csv(PRICES, usecols=["Date"]).Date).max()
    panel = load_panel(PRICES)
    if pd.Timestamp(panel.index.max()) != pd.Timestamp(raw_max).normalize():
        raise RuntimeError("價格最新日有缺列，拒絕把較早收盤當成最新資料")
    sentiment = load_sentiment(SENTIMENT, panel.index)
    if sentiment.loc[pd.Timestamp("2025-08-01"), TICKERS].isna().any():
        raise RuntimeError("實驗情緒副本仍缺少 2025-08-01，拒絕用 0 補上")
    last = panel.index.max()
    if sentiment.loc[last, TICKERS].isna().any():
        raise RuntimeError(f"{last.date()} 情緒未到齊，拒絕沿用前一日情緒")
    frames, risk = build_frames(panel, sentiment)
    one, five, excess = executable_labels(panel)
    return panel, frames, risk, one, five, excess


def update_market(now=None):
    now = now or datetime.now(TZ)
    if now.tzinfo is None:
        raise ValueError("時間必須帶時區")
    completed = pd.Timestamp(current_completed_session(now)).normalize()
    report = {
        "ready_to_predict": False,
        "completed_session": str(completed.date()),
        "clock": now.astimezone(TZ).isoformat(),
        "prices_ready": False,
        "sentiment_ready": False,
        "price_source": PRICE_SOURCE,
        "sentiment_source": SENTIMENT_SOURCE,
        "calendar": CALENDAR,
        "used_previous_day_sentiment": False,
        "v211_module_downloads": False,
        "error": None,
        "appended_price_dates": [],
        "appended_sentiment_dates": [],
    }
    try:
        manifest = seed_market()
        assert_history_intact(manifest)
        errors = []
        try:
            extend_prices(completed, now, report)
        except Exception as exc:
            report["prices_ready"] = False
            errors.append(f"prices: {exc}")
        try:
            extend_sentiment(completed, now, report)
        except Exception as exc:
            report["sentiment_ready"] = False
            errors.append(f"sentiment: {exc}")
        assert_history_intact(manifest)
        report["error"] = " | ".join(errors) if errors else None
        prices = pd.read_csv(PRICES)
        sentiment = pd.read_csv(SENTIMENT)
        ready, reason = prediction_gate(prices, sentiment, completed)
        report["gate"] = reason
        report["ready_to_predict"] = bool(ready and not errors)
        report["prices_through"] = str(pd.to_datetime(prices.Date).max().date())
        report["sentiment_through"] = str(pd.to_datetime(sentiment.Date).max().date())
        report["price_sha256"] = sha256(PRICES)
        report["sentiment_sha256"] = sha256(SENTIMENT)
        stored = _read_json(STATE).get("sessions", {}).get(str(completed.date()))
        if stored and stored.get("ready_at"):
            report["fetched_at"] = stored["ready_at"]
        elif report["ready_to_predict"]:
            report["fetched_at"] = now.astimezone(TZ).isoformat()
        else:
            report["fetched_at"] = None
        if report["ready_to_predict"]:
            _remember(completed, report)
        report["official_price_changed_since_seed"] = sha256(OFFICIAL_PRICES) != manifest["official_price_sha256_at_seed"]
        report["official_sentiment_changed_since_seed"] = sha256(OFFICIAL_SENTIMENT) != manifest["official_sentiment_sha256_at_seed"]
    except Exception as exc:
        report["ready_to_predict"] = False
        report["error"] = str(exc)
    _append_audit(report)
    return report
