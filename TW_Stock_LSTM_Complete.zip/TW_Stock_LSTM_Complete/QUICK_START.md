# 快速開始

1. 解壓縮整個資料夾。
2. 開啟命令提示字元，進入解壓後的資料夾。
3. 執行 `install.bat`，等待虛擬環境與套件安裝完成。
4. 執行 `check_environment.bat`。它會檢查 Python 3.12、權重雜湊與模型是否載入。
5. 選擇一種執行方式：

```bat
run_444.bat
run_555.bat
run_555_v2.bat
run_v211.bat
run_all.bat
```

也可以直接使用虛擬環境裡的 Python：

```bat
.venv\Scripts\python.exe scripts\run_model.py --model 555_v2 --mode full
.venv\Scripts\python.exe scripts\run_all_daily.py --mode full
```

`--mode check` 不重新訓練 444、555，也不下載新資料。它用來確認入口、雜湊與既有資料。正式每日執行使用 `--mode full` 或批次檔。工作排程不是必要步驟。

離線重現 444、555 的原始 50 epoch 訓練：

```bat
run_reproducible_444.bat
run_reproducible_555.bat
```

資料截止日固定為 2026-11-04。輸出分別在 `outputs/444/reproducible-2026-11-04/` 與 `outputs/555/reproducible-2026-11-04/`。

結束代碼：

- `0`：這次要求的工作完成。對 V2.11 來說，只有當日訊號已發布或已存在才是 0。
- `2`：資料未到齊、非當日交易時段，或另一個執行還在跑。可以稍後重試。
- `1`：雜湊不符、檔案被改寫或其他失敗。

昨天的訊號不會讓今天變成結束代碼 0。
