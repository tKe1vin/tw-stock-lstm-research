@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
py -3.12 -c "import sys; raise SystemExit(0 if sys.version_info[:2]==(3, 12) else 1)"
if errorlevel 1 (
  echo 需要 Python 3.12。請從 python.org 安裝，並確認 py -3.12 可用。
  echo 這個安裝不會修改 Windows 全域 Python。
  exit /b 1
)
if not exist .venv\Scripts\python.exe (
  py -3.12 -m venv .venv
  if errorlevel 1 exit /b 1
)
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m pip install torch --index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe scripts\verify_models.py
if errorlevel 1 exit /b 1
echo 安裝完成。請接著執行 check_environment.bat。
exit /b 0
