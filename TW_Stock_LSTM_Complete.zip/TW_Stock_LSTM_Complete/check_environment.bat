@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo 尚未安裝。請先執行 install.bat。
  exit /b 1
)
.venv\Scripts\python.exe scripts\verify_package.py
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe scripts\verify_models.py
if errorlevel 1 exit /b 1
echo 環境檢查完成。
exit /b 0
